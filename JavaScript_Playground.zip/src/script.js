const Discord = require('discord.js');
const bot = new Discord.Client();
const token = 'MTExMjA4MzExNzk4NjAzNzg0Mg.GlX6jk.HH0Qg9w0RGk4pj5cMzgbFdZ1XNB1TdqFEXEiPk';
bot.on('guildBanAdd', (guild, user) => {
  const canalEspecifico = bot.channels.cache.get('1112083893504450654');
  canalEspecifico.send(`<@${user.id}> foi banido.`);
});
bot.login(token);


